﻿function lagreBestilling() {
    const reize = {
        telefonnr: $("#telefonnr").val(),

        reiseFra: $("#reiseFra").val(),
        reiseTil: $("#reiseTil").val(),
        bilettType: $("#bilettType").val()
    };
    const url = "Reise/SettInn";
    $.post(url, reize, function () {
        window.location.href = "index.html";
    });
};