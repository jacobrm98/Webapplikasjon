﻿namespace Losning_pizza_1_core.Models
{
    public class Reise
    {
        public string ReiseFra { get; set; }
        public string ReiseTil { get; set; }
        public int BilettType { get; set; }

        public string Telefonnr { get; set; }
    }
}
