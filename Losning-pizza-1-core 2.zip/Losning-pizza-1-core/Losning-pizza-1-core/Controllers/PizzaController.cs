﻿using System.Collections.Generic;
using System.Linq;
using Losning_pizza_1_core.Models;
using Microsoft.AspNetCore.Mvc;

namespace Losning_pizza_1_core.Controllers
{
    [Route("[controller]/[action]")]
    public class PizzaController:ControllerBase
    {
        private readonly PizzaContext _db;

        public PizzaController(PizzaContext db)
        {
            _db = db;
        }

        [HttpPost]
        public void SettInn(Reise bestiltBilett)
        {
            // returnerer ikke noe, ingen feilhåndtering mot databasen her

            var bestilling = new Bestilling()
            {
                BilettType = bestiltBilett.BilettType,
                ReiseFra = bestiltBilett.ReiseFra,
                ReiseTil = bestiltBilett.ReiseTil
            };

            Kunde funnetKunde = _db.Kunder.FirstOrDefault(k => k.Telefonnr == bestiltBilett.Telefonnr); //Lagre kunden etter telfonnummer

            if (funnetKunde == null)
            {
                // opprett kunden    // Opprett bestilling
                var kunde = new Kunde
                {
                   
                    Telefonnr = bestiltBilett.Telefonnr,
                };
                // legg bestillingen inn i kunden     // Legg ruten inn i bestillingen
                kunde.Bestillinger = new List<Bestilling>();
                kunde.Bestillinger.Add(bestilling);
                _db.Kunder.Add(kunde);
                _db.SaveChanges();
            }
            else
            {
                funnetKunde.Bestillinger.Add(bestilling);
                _db.SaveChanges();
            }
        }

        


        //Lister opp alle bestillinger - det trenger vi ikkje
        public List<Reise> HentAlle()
        {
            List<Kunde> alleKunder = _db.Kunder.ToList();
            List<Reise> alleBestillinger = new List<Reise>();
            foreach (var kunde in alleKunder)
            {
                foreach (var best in kunde.Bestillinger)
                {
                    var enBestilling = new Reise
                    {
                 
                        Telefonnr = kunde.Telefonnr,
                        ReiseFra = best.ReiseFra,
                        BilettType = best.BilettType,
                        ReiseTil = best.ReiseTil
                    };
                    alleBestillinger.Add(enBestilling);
                }
            }
            return alleBestillinger;
        }
    }
}
