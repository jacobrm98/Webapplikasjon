﻿using System;
namespace GruppeOppgave1.Controller
{
    public class Testing
    {
        public Testing()
        {
            //Dette er en test.
            //Hei hei
            //Halo
            //På do
        }
    }
}
