﻿using System;
using GruppeOppgave1.Model;
using Microsoft.AspNetCore.Mvc;

namespace GruppeOppgave1.Controller
{
    [Route("[controller]/[action]")]

    public class RuteController : ControllerBase
    {
        
        private readonly ruteDB _ruteDB;

        public RuteController(ruteDB ruteDB)
        {
            _ruteDB = ruteDB;
        }

        public Rute hentRute(int id)
        {
            Rute enRute = _ruteDB.Ruter.Find(id);
            return enRute;
        }

    }
    
}
