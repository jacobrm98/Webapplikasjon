﻿using System;
using System.Linq;
using GruppeOppgave1.Model;
using Microsoft.AspNetCore.Mvc;

namespace GruppeOppgave1.Controller
{
    [Route("[controller]/[action]")]

    public class RuteController : ControllerBase
    {

        private readonly reiseContext _db;

        public RuteController(reiseContext db)
        {
            _db = db;
        }

        [HttpPost]

        /*public void SettInn(Reise bestiltReise)
        {
            var bestilling = new Rute()
            {
                reiseFra = bestiltReise.reiseFra,
                reieTil = bestiltReise.reieTil,
                pris = bestiltReise.pris,
            };

            Rute funnetRute = _db.Ruter.FirstOrDefault(r => r. == bestiltReise.telefonnr);

            if (funnetRute == null)
            {
                //Oppretter bestilling
                var bestilling = new Bestilling()
                {
                    telefonnr = bestiltReise.telefonnr,
                    email = bestiltReise.email,
                };
            }*/
        public void SettInn(Reise bestiltReise)
        {
            var bestilling = new Bestilling
            {
                telefonnr = bestiltReise.telefonnr,
                email = bestiltReise.email,
            };
            Rute funnetRute1 = _db.Ruter.FirstOrDefault(r => r.reiseFra == bestiltReise.reiseFra);

            Rute funnetRute2 = _db.Ruter.FirstOrDefault(r => r.reiseTil == bestiltReise.reiseTil);

            if (funnetRute1)
            {
                _db.Add(bestiltReise);
            }
        }


      /*  public bool LagreBestilling(Bestilling innBestilling)
        {
            try
            {
                _db.Bestillinger.Add(innBestilling);
                return true;

            }
            catch
            {
                return false;
            }
        }

        public Bestilling HentEnBestilling(int id)
        {
            try
            {
                Bestilling enBestilling = _db.Bestillinger.Find(id);
                return enBestilling;

            }
            catch
            {
                return null;
            }
        }


        public Rute SjekkRute(string reiseFra, string reiseTil)
        {
            try
            {
                Rute enRute = _db.Ruter.Find(reiseFra+reiseTil);
                return enRute;

            }
            catch
            {
                return null;
            }

        }
    }*/
}
    

