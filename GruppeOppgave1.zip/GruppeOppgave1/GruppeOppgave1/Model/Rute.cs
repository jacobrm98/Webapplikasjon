﻿using System;
namespace GruppeOppgave1.Model
{
    public class Rute
    {
        public int RuteId { get; set; }

        public string reieTil{ get; set; }

        public string reiseFra { get; set; }

        public int pris { get; set; }
    }
}
