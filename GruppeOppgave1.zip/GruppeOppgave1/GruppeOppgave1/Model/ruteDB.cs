﻿using System;
using Microsoft.EntityFrameworkCore;

namespace GruppeOppgave1.Model
{
    public class ruteDB :DbContext
    {
        public ruteDB(DbContextOptions<ruteDB> options) : base(options)
        {
            Database.EnsureCreated();
        }

        public DbSet<Rute> Ruter{ get; set; }
    }
}
