﻿using System;
namespace GruppeOppgave1.Model
{
    public class Reise
    {
        public string reieTil{ get; set; }
        public string reiseFra { get; set; }
        public double pris { get; set; }
        public string telefonnr { get; set; }
        public string email { get; set; }
    }
}
