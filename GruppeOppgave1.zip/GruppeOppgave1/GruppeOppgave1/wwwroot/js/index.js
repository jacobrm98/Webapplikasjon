﻿$(function () {
    $("#bestill").click(function () {

        const input = window.location.search.substring(2);
        const url = "Ruter/SjekkRute?" + reiseFra + reiseTil

        $.post(url, , function (rute) {
            $("#reiseFra").val(rute.reiseFra);
            $("#reiseFra").val(rute.reiseTil);

        }
            ß
        var dato = $("#dato").val();

        var ut = "<h3>Her er din bestilling: </h3>" + rute.reiseFra + " " + rute.reiseTil + " " + dato + " " + rute.pris;
        ut += "<input value='Bekreft' type='button' id='bekreft' class='btn btn-success'/>"

        

        $("#kvittering").html(ut);

    });

});

