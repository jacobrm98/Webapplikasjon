﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace GruppeOppgave1.Model
{
    public class Rute
    {
        [Key]
        public int RId { get; set; }

        public string reiseFra { get; set; }

        public string reiseTil { get; set; }

        public double pris { get; set; }
    }

    public class Bestilling
    {
        [Key]
        public int Bid { get; set; }

        public string telefonnr{ get; set; }

        public string email{ get; set; }

        virtual public Rute rute { get; set; }
    }


    public class reiseContext :DbContext
    {
       
        public reiseContext(DbContextOptions<reiseContext> options) : base(options)
        {
            Database.EnsureCreated();
        }

        public DbSet<Rute> Ruter{ get; set; }
        public DbSet<Bestilling> Bestillinger { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseLazyLoadingProxies();
        }

    }
}
