﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using System;
namespace GruppeOppgave1.Model
{
    public class DBInit
    {
        public static void Initialize(IApplicationBuilder app)
        {
            using (var serviceScope = app.ApplicationServices.CreateScope())
            {
                var context = serviceScope.ServiceProvider.GetService<reiseContext>();


                context.Database.EnsureDeleted();
                context.Database.EnsureCreated();

                var rute1 = new Rute {reiseFra = "Oslo", reiseTil = "Bergen", pris =500 };
                var rute2 = new Rute { reiseFra = "Bergen", reiseTil = "Oslo", pris = 500 };
                var rute3 = new Rute { reiseFra = "Oslo", reiseTil = "Larvik", pris = 300 };


                context.Ruter.Add(rute1);
                context.Ruter.Add(rute2);
                context.Ruter.Add(rute3);

                context.SaveChanges();
            }
        }
    }
}
