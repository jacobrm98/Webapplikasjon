﻿$(function () {

    //Viser ikke inputene

    $("#reiseTil").hide();
    $("#dato").hide();

    //Viser ikke labels
    $("#reise_til").hide();
    $("#_dato").hide();



    $("#bestill").click(function () {

        var reiseFra = $("#reiseFra").val();
        var reiseTil = $("#reiseTil").val();
        var dato = $("#dato").val();

        //Validering av skjema

        var ut = "";
        if (reiseFra == "") {

            ut += "Vennligst fyll ut hvor du vil reise fra";
        }
        else if (reiseTil == "") {
            ut += "Vennligst fyll ut hvor du vil reise til";

        }
        else if (dato == "") {
            ut += "Vennligst fyll ut dato du vil reise";

        }

        else {
            var ut = "<h3>Her er din bestilling: </h3>" + reiseFra + " " + reiseTil + " " + dato + " </br>";
            ut += "<input value='Bekreft' type='button' id='bekreft' onclick='nySide' class='btn btn-success'/>"; 
        }

        $("#kvittering").html(ut);

    });

$("#reiseFra").change(function () {

    $("#reiseTil").show();
    $("#reise_til").show();

});

$("#reiseTil").change(function () {

    $("#dato").show();
    $("#_dato").show();

});


$("#avbryt").click(function () {
    //Viser ikke inputene igjen

    $("#reiseTil").hide();
    $("#dato").hide();

    //Viser ikke labels igjen
    $("#reise_til").hide();
    $("#_dato").hide();

    $("#kvittering").html("");
});

    function nySide() {
        location.reload();
    }

});

